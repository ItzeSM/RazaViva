//
//  HackathonTests.swift
//  HackathonTests
//
//  Created by Itzel Santiago on 27/03/25.
//

import Testing
@testable import Hackathon

struct HackathonTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
