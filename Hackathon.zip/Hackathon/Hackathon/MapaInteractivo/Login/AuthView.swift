import SwiftUI
import SwiftData

struct AuthView: View {
    @State private var showLogin = true
    @State private var loggedInUser: Usuario?
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Fondo degradado
                LinearGradient(gradient: Gradient(colors: [Color.blue, Color.purple]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                
                if showLogin {
                    LoginView(showLogin: $showLogin, loggedInUser: $loggedInUser)
                        .transition(.asymmetric(
                            insertion: .move(edge: .leading),
                            removal: .move(edge: .leading)
                        )
                } else {
                    RegisterView(showLogin: $showLogin)
                        .transition(.asymmetric(
                            insertion: .move(edge: .trailing),
                            removal: .move(edge: .trailing)
                        )
                }
            }
            .navigationDestination(item: $loggedInUser) { user in
                HomeView(user: user)  // Reemplaza con tu vista principal
            }
        }
    }
}
