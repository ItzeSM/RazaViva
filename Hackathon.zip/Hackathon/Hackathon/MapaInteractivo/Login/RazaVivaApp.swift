//
//  RazaVivaApp.swift
//  RazaViva
//
//  Created by Daniela Sanchez Avila on 03/04/25.
//
import SwiftData
import SwiftUI

@main
struct RazaVivaApp: App {
    var body: some Scene {
        WindowGroup {
            AuthView()
                .modelContainer(for: Usuario.self)  // Asegúrate de registrar el modelo Usuario
        }
    }
}
