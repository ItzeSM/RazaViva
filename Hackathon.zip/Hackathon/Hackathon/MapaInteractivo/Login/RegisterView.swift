//
//  RegisterView.swift
//  RazaViva
//
//  Created by Daniela Sanchez Avila on 03/04/25.
//

import SwiftUI
import SwiftData

struct RegistrarView: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @Query(sort: \Usuario.username) private var usuarios: [Usuario]
    
    // Campos del formulario
    @State private var nombre = ""
    @State private var apellido = ""
    @State private var email = ""
    @State private var username = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    
    // Estados para manejo de errores
    @State private var showError = false
    @State private var errorMessage = ""
    @State private var isLoading = false
    
    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("Información Personal")) {
                    TextField("Nombre", text: $nombre)
                    TextField("Apellido", text: $apellido)
                    TextField("Email", text: $email)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                        .textContentType(.emailAddress)
                }
                
                Section(header: Text("Credenciales")) {
                    TextField("Usuario", text: $username)
                        .autocapitalization(.none)
                        .autocorrectionDisabled()
                    
                    SecureField("Contraseña", text: $password)
                    SecureField("Confirmar Contraseña", text: $confirmPassword)
                }
                
                if showError {
                    Section {
                        Text(errorMessage)
                            .foregroundColor(.red)
                    }
                }
                
                Section {
                    Button(action: registerUser) {
                        HStack {
                            Spacer()
                            if isLoading {
                                ProgressView()
                            } else {
                                Text("Crear Cuenta")
                            }
                            Spacer()
                        }
                    }
                    .disabled(!formIsValid)
                }
            }
            .navigationTitle("Registro")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") {
                        dismiss()
                    }
                }
            }
        }
    }
    
    // Validación del formulario
    private var formIsValid: Bool {
        !nombre.isEmpty &&
        !apellido.isEmpty &&
        !email.isEmpty &&
        email.contains("@") &&
        !username.isEmpty &&
        password.count >= 6 &&
        password == confirmPassword &&
        !isLoading
    }
    
    private func registerUser() {
        guard formIsValid else { return }
        
        // Validación adicional de email y usuario único
        guard email.isValidEmail else {
            showError(message: "Ingrese un email válido")
            return
        }
        
        guard !usuarios.contains(where: { $0.email.lowercased() == email.lowercased() }) else {
            showError(message: "Este email ya está registrado")
            return
        }
        
        guard !usuarios.contains(where: { $0.username.lowercased() == username.lowercased() }) else {
            showError(message: "Este usuario ya existe")
            return
        }
        
        isLoading = true
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            let newUser = Usuario(
                nombre: nombre,
                apellido: apellido,
                email: email,
                username: username,
                password: password,
                avatar: AvatarManager.avatarAleatorio()
            )
            
            context.insert(newUser)
            
            do {
                try context.save()
                dismiss()
            } catch {
                showError(message: "Error al guardar los datos")
                isLoading = false
            }
        }
    }
    
    private func showError(message: String) {
        errorMessage = message
        withAnimation {
            showError = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            withAnimation {
                showError = false
            }
        }
    }
}

// Extensión para validación de email
extension String {
    var isValidEmail: Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: self)
    }
}
