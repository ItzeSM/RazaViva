//
//  LoginView.swift
//  RazaViva
//
//  Created by Daniela Sanchez Avila on 03/04/25.
//
import SwiftData
import SwiftUI

struct LoginView: View {
    @Binding var showLogin: Bool
    
    @Environment(\.modelContext) private var context
    @Query private var usuarios: [Usuario]
    @State private var username = ""
    @State private var password = ""
    @State private var showError = false
    @State private var isLoading = false
    @State private var isAuthenticated = false
    @State private var loggedInUser: Usuario?
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text("Iniciar Sesión")
                    .font(.largeTitle.bold())
                
                TextField("Usuario", text: $username)
                    .textFieldStyle(.roundedBorder)
                    .autocapitalization(.none)
                
                SecureField("Contraseña", text: $password)
                    .textFieldStyle(.roundedBorder)
                
                if showError {
                    Text("Usuario o contraseña incorrectos")
                        .foregroundColor(.red)
                }
                
                Button("Ingresar") {
                    loginUser()
                }
                .buttonStyle(.borderedProminent)
                .disabled(username.isEmpty || password.isEmpty)
                
                Button("¿No tienes cuenta? Regístrate") {
                                    showRegister = true
                                }
                                .foregroundColor(.blue)
                            }
                            .padding()
                            .sheet(isPresented: $showRegister) {
                                RegistrarView()
                            }
                            .navigationDestination(item: $loggedInUser) { user in
                                AvatarSelectionView(usuario: user)
                            }
                    }
                }
            }
            
    
    private func loginUser() {
        // 1. Validación de campos
        guard !username.isEmpty, !password.isEmpty else {
            withAnimation(.spring) {
                showError = true
            }
            return
        }
        
        isLoading = true
        showError = false
        
        // 2. Simulación de autenticación (0.5 segundos delay)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            // 3. Buscar usuario en la base de datos
            if let user = usuarios.first(where: {
                $0.username.lowercased() == username.lowercased() &&
                $0.password == password
            }) {
                // 4. Login exitoso
                loggedInUser = user
                isAuthenticated = true
                
                // 5. Asignar avatar aleatorio si no tiene
                if user.avatar == "default" {
                    user.avatar = AvatarManager.avatarAleatorio()
                }
            } else {
                // 6. Login fallido
                withAnimation(.easeInOut) {
                    showError = true
                }
            }
            
            isLoading = false
        }
    }
}
