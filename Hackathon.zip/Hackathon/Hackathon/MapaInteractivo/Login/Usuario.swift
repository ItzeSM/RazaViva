//
//  Usuario.swift
//  RazaViva
//
//  Created by Daniela Sanchez Avila on 03/04/25.
//

import Foundation
import SwiftData

@Model
final class Usuario {
    var id: UUID
    var nombre: String
    var apellido: String
    var email: String
    var username: String
    var password: String
    var fechaRegistro: Date
    var avatar: String
    
    init(nombre: String, apellido: String, email: String, username: String, password: String, avatar: String = "default") {
        self.id = UUID()
        self.nombre = nombre
        self.apellido = apellido
        self.email = email
        self.username = username
        self.password = password
        self.fechaRegistro = Date()
        self.avatar = avatar
    }
}
