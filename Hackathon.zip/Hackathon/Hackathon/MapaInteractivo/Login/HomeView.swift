//
//  HomeView.swift
//  RazaViva
//
//  Created by Daniela Sanchez Avila on 03/04/25.
//

import SwiftUI
import SwiftData

struct HomeView: View {
    @Bindable var usuarioActual: Usuario
    
    var body: some View {
        VStack(spacing: 30) {
            // Avatar editable
            NavigationLink {
                AvatarSelectionView(usuario: usuarioActual)
            } label: {
                Image(usuarioActual.avatar)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 120, height: 120)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.blue, lineWidth: 3))
            }
            
            // Información del usuario
            VStack(alignment: .leading, spacing: 10) {
                Text("\(usuarioActual.nombre) \(usuarioActual.apellido)")
                    .font(.title2.bold())
                
                Text("@\(usuarioActual.username)")
                    .foregroundColor(.gray)
                
                Divider()
                
                Text("Registrado el:")
                Text(usuarioActual.fechaRegistro, style: .date)
            }
            .padding()
            
            Spacer()
        }
        .padding()
        .navigationTitle("Inicio")
    }
}
