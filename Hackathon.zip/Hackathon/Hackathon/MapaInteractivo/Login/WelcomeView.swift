import SwiftUI
import SwiftData

struct WelcomeView: View {
    @Bindable var usuario: Usuario
    
    var body: some View {
        VStack(spacing: 30) {
            Image(usuario.avatar)
                .resizable()
                .scaledToFill()
                .frame(width: 150, height: 150)
                .clipShape(Circle())
                .overlay(
                    Circle()
                        .stroke(Color.blue, lineWidth: 4)
                )
                .shadow(radius: 10)
            
            VStack(spacing: 10) {
                Text("¡Bienvenido!")
                    .font(.largeTitle.bold())
                
                Text("@\(usuario.username)")
                    .font(.title2)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
        }
        .padding()
        .navigationTitle("")
        .navigationBarBackButtonHidden(true)
    }
}

