import SwiftUI
import SwiftData
import Foundation

struct ComposerView: View {
    @Environment(\.modelContext) private var modelContext
    @State private var nuevoComentario = ""
    let currentUsername: String
    
    var body: some View {
        HStack {
            TextField("Escribe tu comentario...", text: $nuevoComentario)
                .textFieldStyle(.roundedBorder)
            
            Button(action: sendMessage) {
                Image(systemName: "paperplane.fill")
            }
            .disabled(nuevoComentario.isEmpty)
        }
        .padding()
    }
    
    private func sendMessage() {
        guard !nuevoComentario.isEmpty else { return }
        
        let descriptor = FetchDescriptor<Usuario>(predicate: #Predicate { $0.username == currentUsername })
        if let usuario = try? modelContext.fetch(descriptor).first {
            let comentario = Comentario(
                contenido: nuevoComentario,
                fecha: Date(),
                autor: usuario
            )
            
            modelContext.insert(comentario)
            usuario.comentarios.append(comentario)
            nuevoComentario = ""
        }
    }
}
