import SwiftUI

struct ChatBubbleView: View {
    let comentario: Comentario
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(comentario.autor?.username ?? "Anónimo")
                .fontWeight(.bold)
            Text(comentario.contenido)
            Text(comentario.fecha, style: .time)
                .font(.caption)
                .foregroundColor(.gray)
        }
        .padding(.vertical, 8)
    }
}
