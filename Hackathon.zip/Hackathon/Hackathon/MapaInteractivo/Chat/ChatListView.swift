import SwiftUI
import SwiftData



struct ChatListView: View {
    @Query(sort: \Comentario.fecha, order: .forward) var todosLosMensajes: [Comentario]
    
    var body: some View {
        ScrollViewReader { proxy in
            List(todosLosMensajes) { mensaje in
                ChatBubbleView(mensaje: mensaje)
                    .id(mensaje.id)
            }
            .onChange(of: todosLosMensajes.count) { _ in
                if let last = todosLosMensajes.last {
                    proxy.scrollTo(last.id, anchor: .bottom)
                }
            }
        }
    }
}
