import SwiftData
import Foundation // Add this import

@Model
final class Comentario {
    var id: UUID
    var content: String
    var createdAt: Date
    var author: Usuario?
    
    init(content: String, author: Usuario? = nil) {
        self.id = UUID()
        self.content = content
        self.createdAt = Date()
        self.author = author
    }
}
