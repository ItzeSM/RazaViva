
import SwiftUI

struct GrowingButton: ButtonStyle {
    var pressedScale: CGFloat = 1.8
    var animationDuration: Double = 0.2
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? pressedScale : 1)
            .animation(.easeOut(duration: animationDuration), value: configuration.isPressed)
    }
}

struct ContentViewM: View {
    @State private var selectedState: String? = nil
    @State private var showSidebar: Bool = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Fondo azul
                Color(red: 137/255, green: 194/255, blue: 217/255)
                
                    .edgesIgnoringSafeArea(.all)
                
                
                // Mostrar nombre del estado seleccionado
                if let stateName = selectedState {
                    Text(stateName)
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.white)
                        .padding(10)
                        .background(Color.black.opacity(0.7))
                        .cornerRadius(10)
                        .position(x: UIScreen.main.bounds.width / 2, y: 50)
                        .zIndex(1000)
                        .transition(.opacity)
                }
                
                // Botón de barra lateral en la esquina superior derecha
                //VStack {
                //HStack {
                //Spacer()
                //Button(action: {
                //showSidebar.toggle()
                // }) {
                //Image(systemName: "bubble.left.and.bubble.right.fill")
                //.resizable()
                //.frame(width: 50, height: 40)
                //.foregroundColor(Color.black)
                //.padding()
                //.background(Color.white.opacity(0.8))
                //.clipShape(Circle())
                //.shadow(radius: 5)
                //.position(x: 750, y: 50)
                // }
                //.padding()
                //}
                //Spacer()
                
                //}
                
                // Contenedor para todos los botones
                Group {
                    // Botón 1 (Quintana Roo)
                    NavigationLink(destination: QuintanaRoo()) {
                        ZStack {
                            Image("QuintanaRoo")
                                .resizable()
                                .frame(width: 67, height: 199)
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: 373, y: 182)
                    
                    
                    // Botón 2 (Yucatán)
                    NavigationLink(destination: YucatanView()) {
                        ZStack {
                            Image("Yucatan")
                                .resizable()
                                .frame(width: 99, height: 125)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: 340, y: 153)
                    
                    // Botón 3 (Campeche)
                    NavigationLink(destination: Campeche()) {
                        ZStack {
                            Image("Campeche")
                                .resizable()
                                .frame(width: 149, height: 145)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: 284, y: 211)
                    
                    // Botón 4 (Tabasco)
                    NavigationLink(destination: Tabasco()) {
                        ZStack {
                            Image("Tabasco")
                                .resizable()
                                .frame(width: 150, height: 65)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: 209, y: 276)
                    
                    // Botón 5 (Chiapas)
                    NavigationLink(destination: Chiapas()) {
                        ZStack {
                            Image("Chiapas")
                                .resizable()
                                .frame(width: 161, height: 105)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: 226, y: 331)
                    
                    // Botón 6 (Veracruz)
                    NavigationLink(destination: Veracruz()) {
                        ZStack {
                            Image("Veracruz")
                                .resizable()
                                .frame(width: 180, height: 200)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: 75, y: 211)
                    
                    // Botón 7 (Oaxaca)
                    NavigationLink(destination: OaxacaView()) {
                        ZStack {
                            Image("Oaxaca")
                                .resizable()
                                .frame(width: 175, height: 105)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: 76, y: 306)
                    
                    // Botón 8 (Puebla)
                    NavigationLink(destination: Puebla()) {
                        ZStack {
                            Image("Puebla")
                                .resizable()
                                .frame(width: 80, height: 111)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: 19, y: 231)
                    
                    // Botón 9 (Tlaxcala)
                    NavigationLink(destination: Tlaxcala()) {
                        ZStack {
                            Image("Tlaxcala")
                                .resizable()
                                .frame(width: 40, height: 26)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: 9, y: 230)
                    
                    // Botón 10 (México)
                    NavigationLink(destination: EstadoMexico()) {
                        ZStack {
                            Image("Mexico")
                                .resizable()
                                .frame(width: 69, height: 90)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -38, y: 228)
                    
                    // Botón 11 (Morelos)
                    NavigationLink(destination: Morelos()) {
                        ZStack {
                            Image("Morelos")
                                .resizable()
                                .frame(width: 40, height: 35)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -21, y: 254)
                    
                    // Botón 12 (Guerrero)
                    NavigationLink(destination: Guerrero()) {
                        ZStack {
                            Image("Guerrero")
                                .resizable()
                                .frame(width: 135, height: 90)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -53, y: 294)
                    
                    // Botón 13 (CDMX)
                    NavigationLink(destination: CDMX()) {
                        ZStack {
                            Image("CDMX")
                                .resizable()
                                .frame(width: 20, height: 25)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -23, y: 232)
                    
                    // Botón 14 (Michoacán)
                    NavigationLink(destination: Michoacan()) {
                        ZStack {
                            Image("Michoacan")
                                .resizable()
                                .frame(width: 120, height: 95)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -111, y: 241)
                    
                    // Botón 15 (Hidalgo)
                    NavigationLink(destination: Hidalgo()) {
                        ZStack {
                            Image("Hidalgo")
                                .resizable()
                                .frame(width: 64, height: 75)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -17, y: 190)
                    
                    // Botón 16 (Querétaro)
                    NavigationLink(destination: Queretaro()) {
                        ZStack {
                            Image("Queretaro")
                                .resizable()
                                .frame(width: 55, height: 59)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -48, y: 178)
                    
                    // Botón 17 (Guanajuato)
                    NavigationLink(destination: Guanajuato()) {
                        ZStack {
                            Image("Guanajuato")
                                .resizable()
                                .frame(width: 75, height: 70)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -80, y: 178)
                    
                    // Botón 18 (San Luis Potosí)
                    NavigationLink(destination: SanLuisPotosi()) {
                        ZStack {
                            Image("SanLuisPotosi")
                                .resizable()
                                .frame(width: 125, height: 142)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -62, y: 101)
                    
                    // Botón 19 (Colima)
                    NavigationLink(destination: Colima()) {
                        ZStack {
                            Image("Colima")
                                .resizable()
                                .frame(width: 45, height: 38)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -178, y: 241)
                    
                    // Botón 20 (Jalisco)
                    NavigationLink(destination: Jalisco()) {
                        ZStack {
                            Image("Jalisco")
                                .resizable()
                                .frame(width: 125, height: 135)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -162, y: 181)
                    
                    // Botón 21 (Nayarit)
                    NavigationLink(destination: Nayarit()) {
                        ZStack {
                            Image("Nayarit")
                                .resizable()
                                .frame(width: 87, height: 90)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -211, y: 148)
                    
                    // Botón 22 (Zacatecas)
                    NavigationLink(destination: Zacatecas()) {
                        ZStack {
                            Image("Zacatecas")
                                .resizable()
                                .frame(width: 114, height: 155)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -132, y: 100)
                    
                    // Botón 23 (Aguascalientes)
                    NavigationLink(destination: YucatanView()) {
                        ZStack {
                            Image("Aguascalientes")
                                .resizable()
                                .frame(width: 36, height: 30)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -124, y: 138)
                    
                    // Botón 24 (Durango)
                    NavigationLink(destination: Durango()) {
                        ZStack {
                            Image("Durango")
                                .resizable()
                                .frame(width: 140, height: 170)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -198, y: 52)
                    
                    // Botón 25 (Sinaloa)
                    NavigationLink(destination: Sinaloa()) {
                        ZStack {
                            Image("Sinaloa")
                                .resizable()
                                .frame(width: 95, height: 180)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -262, y: 36)
                    
                    // Botón 26 (Tamaulipas)
                    NavigationLink(destination: Tamaulipas()) {
                        ZStack {
                            Image("Tamaulipas")
                                .resizable()
                                .frame(width: 90, height: 184)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -13, y: 33)
                    
                    // Botón 27 (Nuevo León)
                    NavigationLink(destination: NuevoLeon()) {
                        ZStack {
                            Image("NuevoLeon")
                                .resizable()
                                .frame(width: 90, height: 149)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -48, y: 17)
                    
                    // Botón 28 (Coahuila)
                    NavigationLink(destination: Coahuila()) {
                        ZStack {
                            Image("Coahuila")
                                .resizable()
                                .frame(width: 125, height: 175)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -111, y: -39)
                    
                    // Botón 29 (Chihuahua)
                    NavigationLink(destination: Chihuahua()) {
                        ZStack {
                            Image("Chihuahua")
                                .resizable()
                                .frame(width: 150, height: 194)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -228, y: -85)
                    
                    // Botón 30 (Sonora)
                    NavigationLink(destination: Sonora()) {
                        ZStack {
                            Image("Sonora")
                                .resizable()
                                .frame(width: 90, height: 202)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -330, y: -114)
                    
                    // Botón 31 (Baja California)
                    NavigationLink(destination: BajaCalifornia()) {
                        ZStack {
                            Image("BajaCalifornia")
                                .resizable()
                                .frame(width: 80, height: 202)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -386, y: -120)
                    
                    // Botón 32 (Baja California Sur)
                    NavigationLink(destination: BajaCaliforniaSur()) {
                        ZStack {
                            Image("BajaCaliforniaSur")
                                .resizable()
                                .frame(width: 79, height: 202)
                            
                        }
                    }
                    .buttonStyle(GrowingButton())
                    .offset(x: -342, y: 75)
                    VStack {
                        Spacer()
                        HStack {
                            Image("logo")
                                .resizable()
                                .frame(width: 190, height: 110)
                                .padding()
                            Spacer()
                        }
                    }
                    
                    VStack {
                        Spacer()
                        HStack {
                            Image("mezcal")
                                .resizable()
                                .frame(width: 100, height: 100)
                                .position(x: 150, y: 380)
                            Spacer()
                        }
                        Spacer()
                    }
                    
                    VStack {
                        Spacer()
                        HStack {
                            Image("mexicano")
                                .resizable()
                                .frame(width: 80, height: 100)
                                .position(x: 650, y: 790)
                            Spacer()
                        }
                        Spacer()
                    }
                    
                    VStack {
                        Spacer()
                        HStack {
                            Image("captus")
                                .resizable()
                                .frame(width: 80, height: 100)
                                .position(x: 380, y: 500)
                            Spacer()
                        }
                        Spacer()
                    }
                    
                    
                    VStack {
                        Spacer()
                        HStack {
                            Image("mexicoletra")
                                .resizable()
                                .frame(width: 500, height: 200)
                                .position(x: 500, y: 280)
                            Spacer()
                        }
                        Spacer()
                    }
                    
                    VStack {
                        Spacer()
                        HStack {
                            Image("jaguar")
                                .resizable()
                                .frame(width: 80, height: 100)
                                .position(x: 650, y: 1000)
                            Spacer()
                        }
                        Spacer()
                    }
                    
                    VStack {
                        Spacer()
                        HStack {
                            Image("piramide")
                                .resizable()
                                .frame(width: 170, height: 100)
                                .position(x: 310, y: 950)
                            Spacer()
                        }
                        Spacer()
                    }
                    
                    
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .edgesIgnoringSafeArea(.all)
            .animation(.easeInOut, value: selectedState)
        }
    }
}
#Preview {
    ContentViewM()
}
