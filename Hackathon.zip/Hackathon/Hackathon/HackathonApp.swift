//
//  HackathonApp.swift
//  Hackathon
//
//  Created by Itzel Santiago on 27/03/25.
//

import SwiftUI

@main
struct HackathonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
            
        }
    }
}
#Preview {
    Chiapas()
}
