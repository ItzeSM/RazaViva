//
//  RecetaBebiChis.swift
//  Hackathon
//
//  Created by Itzel Santiago on 03/04/25.
//

import SwiftUI

struct RecetaBebiChis: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("TamalChis")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Tamales de Puerco de Chiapas")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de harina de maiz\n• 500g del guiso de tu preferencia\n• 500 gramos de manteca de cerdo\n• 1 cucharada de sal\n **PARA EL RELLENO DE LOS TAMALES** \n•250 gramos del guiso de tu preferencia\n• 3 chiles anchos\n• 3 chiles mulado\n• 2 chiles pasilla\n• 4 thuevos cocidos\n• 2 Tomates\n• 50 gramos de almendra\n• 100 gramos de pasas\n• 2 cucharadas de ajonjolí tostado\n• 1/2 cucharada de orégano\n• 6 pimientas delgadas\n• 2 dientes de ajo\n• c/n de hojas grandes de plátano")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Lava las hojas de plátano y quitamos los nervios. Las cocemos en agua hirviendo para que se ablanden. Las reservamos.\n\n2. Mezclamos la harina con una taza de caldo del guiso de nuestra preferencia, añadimos la manteca y la sal, batimos hasta que en un vaso con agua, una bolita de masa flote.\n\n3. Preparamos los chiles les quitamos las semillas y las venas, los freímos en poco aceite y los ponemos a remojar, a continuación los molemos\n\n4. Freímos en una sartén los tomates verdes, los jitomates con los dientes de ajo y la cebolla, a continuación los molemos.\n\n5. Freímos un poco las almendras para a continuación moler con el ajonjolí, las pasitas, el orégano, y las pimientas.\n\n6. En un recipiente grande añadimos dos cucharadas de manteca e incorporamos las especias molidas, después echamos los chiles molidos y continuamos moviendo. Finalmente agrega los tomates molidos.\n\n7. Añadimos media taza del caldo del guiso que elegimos, sazonamos con sal y un poco de azúcar.\n\n8. Hacemos los tamales con las hojas de plátano cortadas en cuadrados de unos 20 cm de lado, añadimos el guiso que previamente escogimos, con una cucharada de mole, una pasita, una aceituna, una almendra, y una rebanada de huevo cocido.\n\n9. Cerramos los tamales con los extremos de la hoja, procurando que queden cuadrados y los atamos con una tirita de hoja de plátano o una cuerda. Los cocemos al vapor a fuego alto, durante 60 minutos aproximadamente")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaBebiChis()
}

