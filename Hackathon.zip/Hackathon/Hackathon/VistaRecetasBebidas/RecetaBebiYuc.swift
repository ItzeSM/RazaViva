//
//  RecetaBebiYuc.swift
//  Hackathon
//
//  Created by Itzel Santiago on 03/04/25.
//

import SwiftUI

struct RecetaBebiYuc: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("Xtabentún")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .padding(.top,30)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional del Licor Xtabentún")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 250 gramos de Maíz nixtamalizado\n• 100 gramos de caco\n• 10 gramos de raja de canela\n• 200 gramos de azucar\n• 2 litros de agua")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Dorar el cacao y quitarle la cáscara.\n\n2. Moler finamente el cacao y la canela, por aparte, moler el maíz procurando que no quede muy fino.\n\n3. Mezclar la pasta del cacao con la masa quedando bien mezclado.\n\n4. Batir el pozol de cacao en el litro de agua y endulzar.\n\n5. Mover antes de servir")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaBebiYuc()
}

