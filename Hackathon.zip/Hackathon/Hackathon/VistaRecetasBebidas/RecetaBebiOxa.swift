//
//  RecetaBebiOxa.swift
//  Hackathon
//
//  Created by Itzel Santiago on 03/04/25.
//

import SwiftUI

struct RecetaBebiOxa: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("Mezcal")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional del Mezcal de Agave de Oaxaca")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes Y Materiales**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• Piñas de agave maduras \n• Horno de tierra o piedra\n• Madera y piedras volcánicas (para la cocción)\n• Molino o tahona (rueda de piedra)\n• Tinas de fermentación de madera o barro\n• Levaduras naturales\n• Alambique de cobre o barro.")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Proceso de Elaboración**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Cosecha del Agave\n Se seleccionan las plantas de agave maduras (pueden tardar entre 6 y 12 años en madurar).\n Se corta la planta dejando solo la piña (corazón del agave).\n\n2. Cocción\n Se excava un horno en la tierra o se usa un horno de piedra.\n Se colocan piedras volcánicas calientes y se enciende un fuego con leña.\n Se agregan las piñas de agave y se cubren con tierra y hojas para su cocción lenta (3 a 5 días).\n Esto carameliza los azúcares del agave, dándole el sabor ahumado característico.\n\n3. Molienda\n Una vez cocido, el agave se tritura en un molino de piedra (tahona) o con mazos de madera hasta obtener una masa fibrosa.\n\n4. Fermentación\n La masa se coloca en tinas de fermentación de madera o barro.\n Se añade agua y se deja fermentar naturalmente (de 5 a 15 días, dependiendo del clima).\n Durante este proceso, los azúcares se convierten en alcohol.\n\n5. Destilación\n Se coloca el mosto fermentado en un alambique de cobre o barro.\n Se calienta para que el alcohol se evapore y luego se condensa en otro recipiente.\n La primera destilación produce un líquido con bajo contenido alcohólico (ordinario).\n Se realiza una segunda destilación para obtener el mezcal con una graduación de 45-55°.\n\n6. Reposo y Embotellado\n Se deja reposar por unas semanas o meses en barricas o botellas de vidrio.\n Finalmente, se embotella y está listo para disfrutar.")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaBebiOxa()
}


