//
//  PostitWithImage.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import Foundation
import SwiftUI

struct PostitWithImage: View {
    var text: String
    var imageName: String
    
    var body: some View {
        ZStack {
            Image("Postit")
                .resizable()
                .scaledToFit()
                .frame(width: 500, height: 500)
            
            VStack(spacing: 10) {
                Text(text)
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .frame(width: 230)
                    .foregroundColor(.black)
                
                if !imageName.isEmpty {
                    Image(imageName)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 80)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
