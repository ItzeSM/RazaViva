//
//  AvatarManager.swift
//  RazaViva
//
//  Created by Daniela Sanchez Avila on 03/04/25.
//
import SwiftUI
import SwiftData

struct AvatarManager {
    static let avataresDisponibles = [
        "chiapaneca",
        "yucateca",
        "yucateco",
        "oaxaqueña",
    ]
    
    static func avatarAleatorio() -> String {
        return avataresDisponibles.randomElement() ?? "default_avatar"
    }
}
