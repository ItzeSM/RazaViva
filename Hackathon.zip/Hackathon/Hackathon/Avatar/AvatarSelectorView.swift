//
//  AvatarSelectorView.swift
//  RazaViva
//
//  Created by Daniela Sanchez Avila on 03/04/25.
//

import SwiftUI

struct AvatarSelectionView: View {
    @Bindable var usuario: Usuario
    @State private var selectedAvatar: String = AvatarManager.avatarAleatorio()
    
    var body: some View {
        VStack(spacing: 30) {
            Text("Elige tu avatar")
                .font(.title.bold())
            
            // Previsualización
            Image(selectedAvatar)
                .resizable()
                .scaledToFill()
                .frame(width: 120, height: 120)
                .clipShape(Circle())
                .padding(.bottom)
            
            // Grid de avatares
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 80))], spacing: 20) {
                ForEach(AvatarManager.avataresDisponibles, id: \.self) { avatar in
                    Button {
                        selectedAvatar = avatar
                    } label: {
                        Image(avatar)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 70, height: 70)
                            .clipShape(Circle())
                            .overlay(
                                Circle()
                                    .stroke(selectedAvatar == avatar ? .blue : .clear, lineWidth: 3)
                            )
                    }
                }
            }
            .padding()
            
            NavigationLink(destination: WelcomeView(usuario: usuario)) {
                Text("Continuar")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .simultaneousGesture(TapGesture().onEnded {
                usuario.avatar = selectedAvatar
            })
        }
        .padding()
        .navigationTitle("Perfil")
        .navigationBarBackButtonHidden(true)
    }
}
