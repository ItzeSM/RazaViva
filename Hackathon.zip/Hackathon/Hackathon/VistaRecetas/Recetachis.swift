import SwiftUI

struct RecetachisView: View {
    @State private var showInfo = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("TamalChis")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Tamales de Puerco de Chiapas")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.black)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.black)

                            Text("• 1 kg de harina de maiz\n• 500g del guiso de tu preferencia\n• 500 gramos de manteca de cerdo\n• 1 cucharada de sal\n **PARA EL RELLENO DE LOS TAMALES** \n•250 gramos del guiso de tu preferencia\n• 3 chiles anchos\n• 3 chiles mulato\n• 2 chiles pasilla\n• 4 huevos cocidos\n• 2 Tomates\n• 50 gramos de almendra\n• 100 gramos de pasas\n• 2 cucharadas de ajonjolí tostado\n• 1/2 cucharada de orégano\n• 6 pimientas delgadas\n• 2 dientes de ajo\n• c/n de hojas grandes de plátano")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.black)

                            Text("1. Lava las hojas de plátano y quita los nervios. Cocerlas en agua hirviendo hasta que ablanden.\n\n2. Mezcla la harina con caldo, añade la manteca y la sal. Bate hasta que una bolita de masa flote en agua.\n\n3. Prepara los chiles quitando semillas y venas. Fríelos y ponlos a remojar antes de moler.\n\n4. Fríe tomates, jitomates, ajo y cebolla. Luego muele todo.\n\n5. Fríe almendras y mezcla con ajonjolí, pasitas, orégano y pimientas.\n\n6. Cocina las especias molidas, añade chiles y tomates molidos, sazona con sal y azúcar.\n\n7. Forma los tamales con hojas de plátano, agrega relleno, mole, pasita, aceituna, almendra y huevo.\n\n8. Cierra los tamales, amarra y cocina al vapor por 60 minutos.")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.5)).shadow(radius: 10))
                }
                .padding(.horizontal, 20)
            }
            
            .background(Color(red: 0.749, green: 0.859, blue: 0.969))

            
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        showInfo.toggle()
                    }) {
                        Image(systemName: "info.circle")
                            .font(.title2)
                            .foregroundColor(.black)
                    }
                }
            }
            .sheet(isPresented: $showInfo) {
                InfoView()
            }
        }
    }
}

struct InfoView: View {
    var body: some View {
        ZStack {
            Color(red: 0.749, green: 0.859, blue: 0.969)
                .edgesIgnoringSafeArea(.all)
            
            Image("adorno")
                .resizable()
                .scaledToFit()
                .frame(width: 1000, height: 450)
                .position(x: 100, y: 80)

            VStack(spacing: 20) {
                Text("Datos Importantes")
                    .font(.title)
                    .fontWeight(.bold)
                
                Text("¿Sabías que?...\n **El tamal chiapaneco tiene su propio Lenguaje**\n En las comunidades indígenas, el tamal tiene significados simbólicos. Por ejemplo, regalar un tamal envuelto sin amarrar es una invitación a la boda. En cambio, si el tamal está mal cocido, se cree que trae mala suerte.")
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .padding()
                
                Button("Cerrar") {
                    dismiss()
                }
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .background(Color.red)
                .cornerRadius(10)
            }
            .padding()
            .background(Color.white) // Rectángulo blanco
            .cornerRadius(20)
            .shadow(radius: 10)
            .padding(20)
        }
    }

    @Environment(\.dismiss) private var dismiss
}


#Preview {
    RecetachisView()
}
