//
//  RecetaYuc.swift
//  Hackathon
//
//  Created by Itzel Santiago on 27/03/25.
//

import SwiftUI

struct RecetaYuc: View {
    @State private var showInfo = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("CochiYuc")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Cochinita Pibil")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    
                    VStack(alignment: .leading, spacing: 25)
                    {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.black)

                            Text("• 2 hojas de plátano pasadas por la flama (para ablandarlas)\n• 1 1/2 kilo de pierna de puerco\n• 1/2 kilo de lomo de puerco con costilla\n• 200 gramos de recado de achiote \n• 1 taza de jugo de naranja agria o mitad de vinagre y mitad de jugo de naranja dulce \n• 1/4 de cucharadita de comino en polvo \n• 1 cucharadita de orégano seco \n• 1 cucharadita de pimienta blanca en polvo \n• 1/2 cucharadita de pimienta negra en polvo \n• 1/2 cucharadita de canela en polvo \n•  5 pimientas gordas toscamente molida \n• 3 dientes de ajo exprimido \n• 1/2 cucharadita de chile piquín \n• Sal al gusto \n• 125 gramos de manteca de cerdo \n **SALSA PARA ACOMPAÑAR**\n•  8 rabanitos muy bien lavados y finamente picados\n• 1 cebolla morada chica picada muy finamente\n•  4 chiles habaneros picados muy finamente\n•  1/2 taza de cilantro picado muy finamente\n• 1 taza de jugo de naranja agria o de vinagre\n• Sal al gusto")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.black)

                            Text("1. Forra una charola de horno con las hojas de plátano, dejando que éstas sobresalgan y coloca la carne sobre las mismas. Disuelve el achiote en el jugo de naranja y añaden las especias, con esta mezcla baña la carne y deja marinar cuando menos ocho horas o de un día para otro en el refrigerador.\n\n2.Posteriormente baña con la manteca derretida y  envuelve muy bien en las hojas de plátano,  tapa con papel de aluminio y hornea con el horno precalentado a 175ºC durante 1½ horas, o hasta que su consistencia sea tan suave que casi se desbarate.\n\n3. Para la salsa mezcla todos los ingredientes y dejar reposar por al menos tres horas. Desmenuza la carne y sirve envuelta en las mismas hojas de plátano, acompaña con la salsa y tortillas recién hechas. ¡Buen provecho!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))
                    
                }
                .padding(.horizontal, 20)
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .clipped()
                        .edgesIgnoringSafeArea(.all)
                )
                
            }
            
            
            .navigationTitle("Receta Cochinita Pibil")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        showInfo.toggle()
                    }) {
                        
                        Image(systemName: "info.circle")
                            .font(.title2)
                            .foregroundColor(.black)
                    }
                    
                    Color(red: 1.0, green: 0.768, blue: 0.8196)
                }
                
            }
            .sheet(isPresented: $showInfo) {
                InfoViewCochinita()
            }
        }
    }
}

struct InfoViewCochinita: View {
    var body: some View {
        ZStack {
            Color(red: 0.896, green: 0.945, blue: 0.878) // Fondo completo
                .edgesIgnoringSafeArea(.all)
            
            Image("adorno1")
                .resizable()
                .scaledToFit()
                .frame(width: 900, height: 600)
                .position(x: 270, y: 580)

            VStack(spacing: 20) {
                Text("Datos Importantes")
                    .font(.title)
                    .fontWeight(.bold)
                
                Text("¿Sabías que?...\n **La cochinita pibil tiene una profunda conexión con la cultura maya**. Tradicionalmente, se cocina en un horno subterráneo llamado *pib*, donde la carne de cerdo se marina con achiote y se envuelve en hojas de plátano antes de ser cubierta con piedras calientes. Este método de cocción ancestral no solo realza su sabor ahumado y jugoso, sino que también simboliza la unión familiar y la herencia gastronómica de Yucatán.")
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .padding()
                
                Button("Cerrar") {
                    dismiss()
                }
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .background(Color.red)
                .cornerRadius(10)
            }
            .padding()
            .background(Color.white) // Rectángulo blanco
            .cornerRadius(20)
            .shadow(radius: 10)
            .padding(20)
        }
    }

    @Environment(\.dismiss) private var dismiss
}


#Preview {
    RecetaYuc()
}
