//
//  RecetaEstadoMex.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaEstadoMex: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("ChorizoVerde")  // Cambia esta imagen por la de Chorizo Verde
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Chorizo Verde de Toluca")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes (Para 6-8 personas)**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de carne molida de cerdo\n• 250g de carne de res molida\n• 4 chiles serranos\n• 2 dientes de ajo\n• 1/2 cebolla\n• 1/2 taza de cilantro fresco\n• 1/4 taza de vinagre blanco\n• 1/4 taza de jugo de limón\n• 1 cucharadita de comino\n• 1 cucharadita de orégano\n• 1 cucharadita de pimienta negra\n• 1/2 cucharadita de sal\n• 1/4 taza de aceite para freír")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. En un sartén, asa los chiles serranos, el ajo y la cebolla hasta que estén ligeramente dorados.\n\n2. Licúa los ingredientes asados con el cilantro fresco, el vinagre blanco, el jugo de limón, el comino, el orégano, la pimienta negra y la sal.\n\n3. Mezcla las carnes molidas de cerdo y res en un tazón grande.\n\n4. Vierte la mezcla de salsa verde sobre la carne y mezcla bien hasta obtener una masa homogénea.\n\n5. Forma el chorizo en pequeños rollos o como prefieras.\n\n6. En una sartén, calienta el aceite y fríe el chorizo hasta que esté bien dorado y cocido.\n\n7. ¡Disfruta tu Chorizo Verde al estilo Toluca!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))
                }
                .padding(.horizontal, 20)
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .clipped()
                        .edgesIgnoringSafeArea(.all)
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaEstadoMex()
}
