//
//  Aguascalientes.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//
import SwiftUI

struct RecetaAguasc: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("TamalChis")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Asado de Boda de Aguascalientes")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Porciones y tiempo
                        VStack(alignment: .leading) {
                            Text("**Porciones**: 4-6 personas")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                            
                            Text("**Tiempo de preparación**: 1 hora")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                        }

                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de carne de cerdo en trozos\n• 5 chiles anchos\n• 3 chiles guajillos\n• 2 dientes de ajo\n• 1/2 cebolla\n• 1 taza de caldo de pollo\n• 1/2 taza de vinagre\n• 1 cucharada de azúcar\n• 1 cucharadita de orégano\n• 1 cucharadita de comino\n• 2 cucharadas de manteca de cerdo\n• Sal y pimienta al gusto")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Tuesta los chiles en un comal y remójalos en agua caliente por 10 minutos.\n\n2. Licúa los chiles con el ajo, cebolla, vinagre, azúcar, orégano, comino y un poco de caldo de pollo hasta obtener una salsa homogénea.\n\n3. En una cacerola, calienta la manteca y sella los trozos de carne de cerdo hasta que estén dorados.\n\n4. Agrega la salsa colada y cocina a fuego medio por 30 minutos, moviendo ocasionalmente.\n\n5. Añade el resto del caldo de pollo, ajusta la sal y deja cocinar por 20 minutos más hasta que la carne esté bien cocida y la salsa espesa.\n\n6. Sirve caliente acompañado de arroz y tortillas. ¡Disfruta!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))
                }
                .padding(.horizontal, 20)
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .clipped()
                        .edgesIgnoringSafeArea(.all)
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaAguasc()
}
