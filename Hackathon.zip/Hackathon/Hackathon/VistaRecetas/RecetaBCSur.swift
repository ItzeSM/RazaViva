//
//  RecetaBCSur.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaBCSur: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("TamalChis")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Almejas Chocolatas de Baja California Sur")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 docena de almejas chocolatas\n• 3 ramas de epazote\n• 2 dientes de ajo picados\n• 1/2 cebolla en rodajas\n• 1 chile serrano picado\n• 2 tomates picados\n• Sal y pimienta al gusto\n• Hojas de plátano\n• Piedras calientes para cocción")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Cava un hoyo en la tierra y coloca piedras calientes en el fondo.\n\n2. Sobre las piedras, coloca las hojas de plátano para evitar el contacto directo con las almejas.\n\n3. Distribuye las almejas sobre las hojas y agrégales epazote, ajo, cebolla, chile y tomate.\n\n4. Cubre con más hojas de plátano y sella con tierra para conservar el calor.\n\n5. Deja cocinar por aproximadamente 30 minutos.\n\n6. Retira con cuidado la tierra y las hojas de plátano, sirve y disfruta de este manjar tradicional.")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))
                }
                .padding(.horizontal, 20)
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .clipped()
                        .edgesIgnoringSafeArea(.all)
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaBCSur()
}
