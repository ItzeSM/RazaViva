//
//  RecetaTab.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaTab: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("Pejelagarto")  // Cambia esta imagen por la de Pejelagarto Asado
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Pejelagarto Asado")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 Pejelagarto entero (fresco o congelado)\n• 2 dientes de ajo\n• 1/2 cebolla\n• Jugo de 2 limones\n• 1 cucharadita de comino\n• 1 cucharadita de sal\n• 1 cucharadita de pimienta\n• 1 cucharadita de chile en polvo (opcional)\n• 1/4 taza de aceite de oliva\n• Hojas de plátano (para envolver)\n• Salsa al gusto (salsa roja o verde)\n• Limones para acompañar")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Limpia y seca el Pejelagarto. Haz unos cortes en el pescado para que se cocine bien.\n\n2. Marina el pescado con ajo picado, cebolla picada, jugo de limón, comino, sal, pimienta y chile en polvo. Deja marinar por al menos 30 minutos.\n\n3. Calienta el aceite de oliva en una sartén o parrilla y coloca el Pejelagarto para asarlo. Cocina hasta que la piel se vea dorada y crujiente, aproximadamente 15-20 minutos por cada lado.\n\n4. Si prefieres, también puedes envolverlo en hojas de plátano y asarlo a la parrilla.\n\n5. Acompaña el Pejelagarto con salsa al gusto y limones partidos.\n\n6. ¡Disfruta de este platillo tradicional tabasqueño!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaTab()
}
