//
//  RecetaGuerre.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaGuerre: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("PozoleVerde")  // Cambia esta imagen por la de Pozole verde
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Pozole Verde")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes (Para 6 personas)**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de maíz pozolero\n• 500g de carne de cerdo (espaldilla o pierna)\n• 1/2 kg de pollo (opcional)\n• 1/4 kg de pepita de calabaza\n• 1/2 cebolla\n• 3 dientes de ajo\n• 3 chiles serranos\n• 2 hojas de laurel\n• 1 cucharadita de orégano seco\n• Sal al gusto\n• Toppings: rábanos, lechuga, cebolla, orégano, chile en polvo, limón")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Cocina el maíz pozolero en una olla grande con agua y un poco de sal hasta que esté suave, aproximadamente 2 horas.\n\n2. En una olla aparte, hierve la carne de cerdo y el pollo (si se usa) con cebolla, ajo, hojas de laurel y sal hasta que esté bien cocida.\n\n3. Mientras, tuesta las pepitas de calabaza y muélelas en una licuadora con los chiles serranos hasta obtener una pasta.\n\n4. Cuando la carne esté lista, desmenúzala y añádela al maíz ya cocido.\n\n5. Agrega la pasta de pepita y chile al pozole, y cocina a fuego lento durante 30 minutos.\n\n6. Sirve el pozole caliente y acompáñalo con rábanos, lechuga, cebolla, orégano, chile en polvo y limón al gusto.\n\n7. ¡Disfruta de tu Pozole Verde al estilo tradicional!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaGuerre()
}
