//
//  RecetaHidal.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaHidal: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("Pastes")  // Cambia esta imagen por la de Pastes
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Pastes")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes (Para 12 pastes)**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de masa para pastes\n• 500g de carne molida o frijoles (opcional)\n• 1/2 cebolla picada\n• 2 dientes de ajo picados\n• 1 cucharadita de comino\n• 1 cucharadita de sal\n• 1/2 taza de aceite\n• 12 piezas de masa para empanadas (o masa casera)\n• 1 huevo batido (para barnizar)")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. En una sartén, cocina la carne con cebolla, ajo, comino y sal hasta que esté bien cocida.\n\n2. Si estás usando frijoles, puedes mezclarlos con la carne o hacer una mezcla por separado con frijoles cocidos y triturados.\n\n3. Estira la masa en pequeños círculos y coloca una cucharada del relleno en el centro.\n\n4. Cierra los pastes formando una empanada y presiona los bordes con un tenedor para sellarlos.\n\n5. Barniza con huevo batido y hornea en horno precalentado a 180°C por 20-25 minutos, o hasta que estén dorados.\n\n6. Sirve los pastes calientes y disfruta de este delicioso platillo heredado de los mineros ingleses.")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaHidal()
}
