//
//  RecetaNL.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaNL: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("CabritoAsado")  // Cambia esta imagen por la de Cabrito Asado
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Cabrito Asado")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 cabrito (aproximadamente 2 kg)\n• 4 dientes de ajo\n• 1 cucharadita de comino\n• 1 cucharadita de paprika\n• 1 cucharadita de orégano\n• 1/4 taza de vinagre blanco\n• Jugo de 3 limones\n• 2 cucharadas de aceite de oliva\n• Sal y pimienta al gusto\n• Ramitas de romero (opcional)\n• Hojas de plátano (opcional)")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Limpia el cabrito y marínalo con ajo picado, comino, paprika, orégano, vinagre, jugo de limón, aceite de oliva, sal y pimienta.\n\n2. Deja marinar el cabrito durante al menos 2 horas o toda la noche en el refrigerador.\n\n3. Prepara una parrilla o asador con brasas.\n\n4. Coloca el cabrito en la parrilla, añadiendo ramitas de romero sobre las brasas para un sabor extra.\n\n5. Cocina el cabrito por aproximadamente 2-3 horas, girándolo cada 30 minutos para que se cocine de manera uniforme.\n\n6. Si deseas, puedes envolver el cabrito en hojas de plátano para añadir un sabor más tradicional.\n\n7. Sirve el cabrito asado acompañado de tortillas y salsa al gusto.\n\n8. ¡Disfruta de tu delicioso Cabrito Asado!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaNL()
}
