//
//  RecetaVera.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaVera: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("Zacahuil")  // Cambia esta imagen por la de Zacahuil
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Zacahuil")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de masa de maíz martajado\n• 500g de carne de cerdo\n• 2 dientes de ajo\n• 1/2 cebolla\n• 1 cucharadita de comino\n• 1 cucharadita de sal\n• 1 cucharadita de pimienta\n• 1 taza de salsa roja o verde\n• 2 hojas de plátano grandes para envolver\n• 1/4 taza de aceite o manteca")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Cocina la carne de cerdo con ajo, cebolla, comino, sal y pimienta hasta que esté bien cocida. Desmenuza la carne.\n\n2. Licúa los ingredientes para la salsa (puede ser roja o verde) y cocínalos en una sartén con aceite hasta que espese.\n\n3. Mezcla la masa de maíz con un poco de agua o caldo de la carne para obtener una masa manejable.\n\n4. Unta una capa de la masa en la hoja de plátano, coloca la carne desmenuzada y cubre con más masa.\n\n5. Envuelve bien el zacahuil con las hojas de plátano, asegurando que no se salga el relleno.\n\n6. Cocina el zacahuil en una vaporera o una olla grande con agua a fuego lento durante 3-4 horas.\n\n7. ¡Disfruta de este delicioso tamal gigante lleno de sabor!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaVera()
}
