//
//  RecetaBajaC.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//
import SwiftUI

struct RecetaBajaC: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("TamalChis")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Tacos de Pescado de Baja California")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Porciones y tiempo
                        VStack(alignment: .leading) {
                            Text("**Porciones:** 4" )
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                            Text("**Tiempo de preparación:** 40 minutos")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                        }

                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 500g de filete de pescado blanco (merluza o tilapia)\n• 1 taza de harina de trigo\n• 1 taza de cerveza clara\n• 1 cucharadita de polvo para hornear\n• 1 cucharadita de sal\n• 1/2 cucharadita de pimienta\n• 1/2 cucharadita de ajo en polvo\n• Aceite para freír\n• 8 tortillas de maíz\n• 1 taza de col rallada\n• 1/2 taza de mayonesa\n• 1 cucharada de jugo de limón\n• Salsa al gusto (chipotle o pico de gallo)")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Corta el pescado en tiras y sécalas con papel absorbente.\n\n2. En un tazón, mezcla la harina, la cerveza, el polvo para hornear, la sal, la pimienta y el ajo en polvo hasta obtener una mezcla homogénea.\n\n3. Calienta suficiente aceite en una sartén a fuego medio-alto.\n\n4. Pasa las tiras de pescado por la mezcla de harina y fríelas en el aceite caliente hasta que estén doradas y crujientes. Escúrrelas sobre papel absorbente.\n\n5. Mezcla la mayonesa con el jugo de limón y reserva.\n\n6. Calienta las tortillas y rellénalas con el pescado frito, la col rallada y la salsa de mayonesa.\n\n7. Agrega la salsa de tu elección y sirve caliente. ¡Disfruta!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))
                }
                .padding(.horizontal, 20)
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .clipped()
                        .edgesIgnoringSafeArea(.all)
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaBajaC()
}
