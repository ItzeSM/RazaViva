//
//  RecetaPue.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaPue: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("ChilesEnNogada")  // Cambia esta imagen por la de Chiles en Nogada
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Chiles en Nogada")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 6 chiles poblanos\n• 500g de carne molida de res y cerdo\n• 1 cebolla\n• 2 dientes de ajo\n• 1/2 taza de almendras\n• 1/2 taza de pasas\n• 1/2 taza de duraznos picados\n• 1/4 taza de acitrón\n• 1 taza de jitomates pelados\n• 1 cucharadita de canela\n• 1 cucharadita de clavo molido\n• 1/2 taza de aceite\n• 1 taza de nuez de la India molida\n• 1 taza de crema\n• 1/4 taza de jerez\n• Granada (para decorar)\n• Sal y pimienta al gusto")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Asa los chiles poblanos hasta que la piel se dore, luego colócalos en una bolsa de plástico para que suden y sea más fácil pelarlos. Pela y desvena los chiles.\n\n2. En una sartén, calienta un poco de aceite y fríe la carne molida de res y cerdo con la cebolla y el ajo picados. Agrega sal, pimienta, canela y clavo molido.\n\n3. Añade las almendras, pasas, duraznos picados, acitrón y los jitomates pelados. Cocina hasta que se mezclen bien los ingredientes.\n\n4. Rellena los chiles poblanos con la mezcla de carne y frutas.\n\n5. Para la salsa de nogada, licúa la nuez de la India con la crema y el jerez hasta obtener una mezcla suave.\n\n6. Vierte la salsa de nogada sobre los chiles rellenos.\n\n7. Decora con granada y sirve los chiles en nogada acompañados de arroz blanco.\n\n8. ¡Disfruta tus Chiles en Nogada al estilo tradicional!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaPue()
}
