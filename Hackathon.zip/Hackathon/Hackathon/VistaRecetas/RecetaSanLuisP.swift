//
//  RecetaSanLuisP.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaSanLuisP: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("EnchiladasPotosinas")  // Cambia esta imagen por la de Enchiladas Potosinas
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Enchiladas Potosinas")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 12 tortillas de maíz\n• 300g de queso fresco\n• 2 chiles guajillos\n• 1 tomate\n• 1/4 de cebolla\n• 1 diente de ajo\n• 1/2 cucharadita de comino\n• 1 cucharadita de sal\n• 1/2 cucharadita de pimienta\n• Aceite para freír\n• Crema al gusto\n• Lechuga finamente picada para acompañar")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Asa los chiles guajillos y los tomates, luego licúalos junto con la cebolla, ajo, comino, sal y pimienta hasta obtener una salsa suave.\n\n2. Calienta un poco de aceite en un sartén y vierte la salsa. Cocina a fuego bajo hasta que la salsa espese un poco.\n\n3. Calienta las tortillas y pásalas por la salsa caliente.\n\n4. Rellena las tortillas con el queso fresco y enróllalas.\n\n5. Fría las enchiladas en aceite caliente hasta que estén doradas y crujientes.\n\n6. Sirve las enchiladas potosinas con crema y lechuga picada al gusto. ¡Disfruta de este delicioso platillo de San Luis Potosí!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaSanLuisP()
}
