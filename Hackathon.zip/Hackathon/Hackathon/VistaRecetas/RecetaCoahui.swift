//
//  RecetaCoahui.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaCoahui: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("TamalChis")  // Cambia esta imagen por la de Discada
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Discada")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes (Para 4-6 personas)**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 500g de carne de res (en trozos)\n\n• 500g de carne de cerdo (en trozos)\n\n• 200g de tocino (en trozos)\n\n• 1 cebolla grande (picada)\n\n• 3 dientes de ajo (picados)\n\n• 3 chiles jalapeños (en rodajas)\n\n• 2 papas medianas (peladas y en cubos)\n\n• 1 pimiento morrón (picado)\n\n• 2 tomates (picados)\n\n• 1 cucharadita de comino\n\n• 1 cucharadita de orégano\n\n• Sal y pimienta al gusto\n\n• Aceite para freír\n\n• Tortillas de harina o maíz (para acompañar)")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. En un disco de arado o sartén grande, calienta un poco de aceite y fríe el tocino hasta que esté dorado.\n\n2. Agrega las carnes de res y cerdo, y cocina hasta que estén bien doradas por todos lados.\n\n3. Añade la cebolla, el ajo, los jalapeños, las papas, el pimiento morrón y los tomates. Cocina todo junto hasta que las papas estén suaves y los tomates se deshagan.\n\n4. Sazona con comino, orégano, sal y pimienta al gusto. Revuelve bien para que los sabores se mezclen.\n\n5. Cocina a fuego medio, removiendo de vez en cuando, durante unos 15-20 minutos hasta que todo esté bien cocido y los sabores se integren.\n\n6. Sirve caliente con tortillas de maíz o harina.")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))
                }
                .padding(.horizontal, 20)
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .clipped()
                        .edgesIgnoringSafeArea(.all)
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaCoahui()
}
