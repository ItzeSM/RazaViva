//
//  RecetaNay.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaNay: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("PescadoZarandeado")  // Cambia esta imagen por la de Pescado Zarandeado
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Pescado Zarandeado")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de pescado (preferiblemente dorado o robalo)\n• 2 dientes de ajo\n• 1 cucharadita de comino\n• 1 cucharadita de paprika\n• 1 cucharadita de sal\n• 1 cucharadita de pimienta\n• Jugo de 2 limones\n• 3 cucharadas de salsa de soya\n• 2 cucharadas de aceite de oliva\n• Ramitas de romero\n• Hojas de plátano (opcional)")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Limpia el pescado y marínalo con ajo picado, comino, paprika, sal, pimienta, jugo de limón, salsa de soya y aceite de oliva.\n\n2. Deja reposar la mezcla durante 30 minutos para que el pescado absorba bien los sabores.\n\n3. Prepara una parrilla o asador y coloca ramitas de romero sobre las brasas.\n\n4. Coloca el pescado sobre la parrilla y cocina por ambos lados hasta que esté bien dorado y cocido (aproximadamente 15-20 minutos).\n\n5. Si lo deseas, envuelve el pescado en hojas de plátano antes de asarlo para darle un toque extra de sabor.\n\n6. Sirve el pescado zarandeado con tortillas y salsa al gusto.\n\n7. ¡Disfruta de tu delicioso Pescado Zarandeado!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaNay()
}
