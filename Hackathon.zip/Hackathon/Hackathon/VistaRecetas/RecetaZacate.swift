//
//  RecetaZacate.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaZacate: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("AsadoBoda")  // Cambia esta imagen por la de Asado de Boda
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Asado de Boda")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de carne de cerdo\n• 3 dientes de ajo\n• 1/2 cebolla\n• 1 cucharadita de comino\n• 1 cucharadita de orégano\n• 1 cucharadita de pimienta\n• 1 taza de salsa roja (chile guajillo)\n• 1/4 taza de aceite\n• 1 hoja de laurel\n• 1/2 taza de caldo de carne\n• Sal al gusto")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Cocina la carne de cerdo con ajo, cebolla, comino, orégano, pimienta y laurel en agua hasta que esté bien cocida.\n\n2. En una sartén, calienta el aceite y añade la salsa roja de chile guajillo. Cocina por unos minutos hasta que espese.\n\n3. Desmenuza la carne y añade la salsa al gusto, dejando cocinar todo junto por unos 10 minutos.\n\n4. Agrega el caldo de carne y ajusta la sal al gusto.\n\n5. Sirve el asado acompañado de arroz, frijoles y tortillas.\n\n6. ¡Disfruta del delicioso Asado de Boda!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaZacate()
}
