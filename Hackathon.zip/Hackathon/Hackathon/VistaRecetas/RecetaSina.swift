//
//  RecetaSina.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaSina: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("Chilorio")  // Cambia esta imagen por la de Chilorio
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Chilorio")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de carne de cerdo\n• 3 chiles guajillos\n• 2 chiles anchos\n• 1/2 cebolla\n• 2 dientes de ajo\n• 1/2 cucharadita de comino\n• 1/2 cucharadita de orégano\n• 1/4 de taza de vinagre\n• 1/4 de taza de aceite\n• 1 cucharadita de sal\n• 1 cucharadita de pimienta\n• 1/2 taza de caldo de pollo")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Cocina la carne de cerdo en agua con sal hasta que esté bien cocida. Después desmenúzala.\n\n2. Asa los chiles guajillos y anchos, luego licúalos junto con la cebolla, ajo, comino, orégano, vinagre, sal, pimienta y caldo de pollo.\n\n3. Calienta el aceite en una sartén grande y agrega la salsa de chile, cocinándola a fuego medio hasta que espese.\n\n4. Añade la carne desmenuzada a la salsa y cocina por unos minutos, mezclando bien hasta que se impregne bien con la salsa.\n\n5. Sirve el chilorio con tortillas de maíz o en tacos. ¡Disfruta de este delicioso platillo tradicional!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaSina()
}
