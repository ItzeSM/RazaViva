//
//  RecetaSono.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaSono: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("CarneAsada")  // Cambia esta imagen por la de Carne Asada
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Carne Asada")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de carne de res (preferiblemente falda o arrachera)\n• 2 dientes de ajo\n• 1/2 cebolla\n• Jugo de 2 limones\n• 1 cucharadita de comino\n• 1 cucharadita de sal\n• 1 cucharadita de pimienta\n• 1 cucharadita de chile en polvo (opcional)\n• 1/4 taza de aceite\n• 1/4 taza de salsa inglesa\n• 1 aguacate (para guacamole)\n• 1/2 cebolla morada (para guacamole)\n• Cilantro fresco (para guacamole)\n• Limones, cebollitas asadas y salsa al gusto")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Marina la carne con ajo, cebolla, jugo de limón, comino, sal, pimienta, chile en polvo, aceite y salsa inglesa. Deja marinar por al menos 1 hora.\n\n2. Asa la carne en una parrilla o sartén bien caliente por ambos lados hasta el término deseado.\n\n3. Para el guacamole, machaca el aguacate con la cebolla morada y cilantro. Agrega sal al gusto.\n\n4. Acompaña la carne asada con cebollitas asadas, salsa, y limones partidos.\n\n5. Sirve la carne asada con tortillas de maíz o de harina y disfruta de este delicioso platillo tradicional mexicano.")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaSono()
}
