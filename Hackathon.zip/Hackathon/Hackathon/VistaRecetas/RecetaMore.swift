//
//  RecetaMore.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaMore: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("CecinaYecapixtla")  // Cambia esta imagen por la de Cecina de Yecapixtla
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Cecina de Yecapixtla")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de carne de res (preferentemente cecina)\n• 2 dientes de ajo\n• 1/2 cucharadita de comino\n• 1 cucharadita de pimienta\n• 1 cucharadita de orégano\n• 2 cucharadas de vinagre\n• 1/2 cucharadita de sal\n• Jugo de 2 limones\n• Aceite para freír")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. En un recipiente, mezcla el ajo, el comino, la pimienta, el orégano, el vinagre, la sal y el jugo de limón. Agrega la carne de res y mezcla bien para que se marine.\n\n2. Deja reposar la carne en la mezcla por al menos 2 horas, idealmente toda la noche.\n\n3. Coloca la carne en un sartén con un poco de aceite caliente y fríela por ambos lados hasta que quede dorada y crujiente.\n\n4. Sirve la cecina de Yecapixtla acompañada de tortillas y salsa al gusto.\n\n5. ¡Disfruta de tu deliciosa Cecina de Yecapixtla!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaMore()
}
