//
//  RecetaChihua.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaChihua: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("TamalChis")  // Cambia esta imagen por la de Chile Pasado
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Chile Pasado de Chihuahua")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 500g de carne seca de res (deshidratada y desmenuzada)\n\n• 5 chiles guajillos secos\n\n• 2 chiles pasilla secos\n\n• 2 dientes de ajo\n\n• 1/2 cebolla\n\n• 1 cucharadita de comino\n\n• 1/2 cucharadita de orégano seco\n\n• Sal al gusto\n\n• 2 tazas de caldo de carne o agua\n\n• Aceite para freír")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Asa los chiles guajillo y pasilla en un sartén caliente hasta que estén ligeramente dorados, sin que se quemen. Retira los tallos y las semillas.\n\n2. Hidrata los chiles en agua caliente durante 10-15 minutos.\n\n3. Licúa los chiles hidratados, ajo, cebolla, comino, orégano y una taza de caldo hasta obtener una salsa suave.\n\n4. Fría la carne seca desmenuzada en un sartén con un poco de aceite hasta que esté dorada.\n\n5. Agrega la salsa licuada y el caldo restante. Cocina a fuego lento por 20-30 minutos para que los sabores se mezclen.\n\n6. Ajusta la sal al gusto y sirve caliente con tortillas de maíz.")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))
                }
                .padding(.horizontal, 20)
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .clipped()
                        .edgesIgnoringSafeArea(.all)
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaChihua()
}
