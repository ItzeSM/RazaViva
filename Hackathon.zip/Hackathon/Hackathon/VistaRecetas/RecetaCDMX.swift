//
//  RecetaCDMX.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaCDMX: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("TamalChis")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Tacos al Pastor")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de carne de cerdo en trozos\n\n• 3 chiles guajillo\n\n• 2 chiles anchos\n\n• 3 dientes de ajo\n\n• 1/2 cebolla\n\n• 1/2 taza de vinagre blanco\n\n• 1 cucharada de orégano\n\n• 1 cucharadita de comino\n\n• Sal y pimienta al gusto\n\n• 1 taza de jugo de piña\n\n• Tortillas de maíz\n\n• Cebolla picada, cilantro y piña en trozos")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Remoja los chiles en agua caliente, licúalos con ajo, cebolla, vinagre, orégano, comino, sal y jugo de piña.\n\n2. Marina la carne con la mezcla anterior y déjala reposar por al menos 2 horas.\n\n3. Cocina la carne en un sartén o parrilla hasta que esté bien dorada.\n\n4. Corta en tiras finas y sirve en tortillas calientes con cebolla, cilantro y piña.\n\n5. ¡Disfruta tus tacos al pastor al estilo CDMX!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))
                }
                .padding(.horizontal, 20)
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .clipped()
                        .edgesIgnoringSafeArea(.all)
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaCDMX()
}
