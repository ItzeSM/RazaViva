import SwiftUI

struct RecetaOxa: View {
    @State private var showInfo = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("MoleOxa")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Mole")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.black)

                            Text("• 1/4 de chile costeño\n• 1/4 de chile guajillo\n• 1/4 de chile ancho\n• 25 g de pasitas \n• 25 g de almendra \n• 5 g de ajonjolí \n• 1 cabeza de ajo \n• 1 cebolla chica \n• 25 clavos de olor \n• 25 pimientas \n• 4 ramas de canela \n• 1 kg de tomate \n• 1/2 plátano macho frito \n• 1/4 de manteca \n• 1 cucharada de azúcar \n• 1 cucharada de sal \n• 3 tablillas de chocolate")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.black)

                            Text("1. Tuesta bien los chiles; costeño, guajillo y ancho, luego se les sacas las semillas y los lavas tres veces.\n\n2. Cuece en un comal el ajo y la cebolla.\n\n3. Cuece aparte las pasitas.\n\n4. En un comal de barro tuesta las almendras y el ajonjolí. Cuando ya está todo tostado, muélelo.\n\n5. Pon en la lumbre una cazuela de barro, vierte ¼ de manteca; ya que está caliente, agrega el chile molido para que se fría con todos los ingredientes, incluye tres tablillas de chocolate.\n\n6. Agrega el jitomate molido con el ajo y la cebolla, las especias, el pan y el plátano frito.\n\n7. Cuece a fuego lento hasta que tengas la consistencia que deseas.")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))
                }
                .padding(.horizontal, 20)
            }
            .background(Color(red: 0.97, green: 0.70, blue: 0.40)) // Fondo sólido

            
            .navigationTitle("Receta Mole Oaxaca")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        showInfo.toggle()
                    }) {
                        Image(systemName: "info.circle")
                            .font(.title2)
                            .foregroundColor(.black)
                    }
                }
            }
            .sheet(isPresented: $showInfo) {
                InfoViewOxa()
            }
        }
    }
}
struct InfoViewOxa: View {
    var body: some View {
        ZStack {
            Color(red: 0.996, green: 0.980, blue: 0.878)
                .edgesIgnoringSafeArea(.all)

            Image("adorno")
                .resizable()
                .scaledToFit()
                .frame(width: 1000, height: 450)
                .position(x: 100, y: 80)

            VStack(spacing: 20) {
                Text("Datos Importantes")
                    .font(.title)
                    .fontWeight(.bold)

                Text("¿Sabías que?... El Mole de Oaxaca, conocido como el 'Mole Negro', es uno de los moles más emblemáticos de México? Esta mezcla única de chiles, especias, y chocolate ha sido preparada en Oaxaca durante siglos. Se dice que el mole era un regalo de los dioses, con su sabor profundo y complejo, el cual refleja la riqueza cultural y la historia prehispánica de la región.")
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .padding()

                Button("Cerrar") {
                    dismiss()
                }
                .font(.headline)
                .foregroundColor(.white)
                .padding()
                .background(Color.red)
                .cornerRadius(10)
            }
            .padding()
            .background(Color.white)
            .cornerRadius(20)
            .shadow(radius: 10)
            .padding(20)
        }
    }

    @Environment(\.dismiss) private var dismiss
}

#Preview {
    RecetaOxa()
}
