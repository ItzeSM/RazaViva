//
//  RecetaTamauli.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaTamauli: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("CarneTampiquena")  // Cambia esta imagen por la de Carne a la Tampiqueña
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Carne a la Tampiqueña")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de carne de res (como arrachera o lomo)\n• 4 enchiladas rojas\n• 1 taza de frijoles refritos\n• 2 dientes de ajo\n• 1 cucharadita de comino\n• 1 cucharadita de sal\n• 1 cucharadita de pimienta\n• Jugo de 1 limón\n• 1/4 taza de aceite de oliva\n• Limón y salsa al gusto para acompañar")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. Cocina la carne de res a la parrilla o en una sartén con un poco de aceite, ajo, comino, sal, pimienta y jugo de limón. Cocina hasta que esté al término deseado (aproximadamente 3-5 minutos por cada lado).\n\n2. Mientras se cocina la carne, calienta las enchiladas rojas en una sartén con un poco de aceite y reserva.\n\n3. Sirve la carne a la tampiqueña acompañada de las enchiladas rojas, los frijoles refritos y una rodaja de limón.\n\n4. Acompaña con salsa al gusto.\n\n5. ¡Disfruta de este delicioso platillo de la cocina mexicana!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))  // Fondo blanco con opacidad para que se vea la imagen de fondo
                }
                .padding(.horizontal, 20)  // Márgenes horizontales
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)  // Ajusta la imagen para cubrir el área
                        .clipped()  // Recorta la imagen si es necesario
                        .edgesIgnoringSafeArea(.all)  // Imagen de fondo cubriendo toda la pantalla
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaTamauli()
}
