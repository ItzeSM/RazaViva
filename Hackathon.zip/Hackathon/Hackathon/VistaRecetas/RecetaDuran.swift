//
//  RecetaDuran.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct RecetaDuran: View {
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 30) {
                    
                    Text("Bienvenido al Recetario")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .frame(maxWidth: .infinity, alignment: .center)

                    Image("CaldilloDurangueno")  // Cambia esta imagen por la de Caldillo Durangueño
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250, height: 250)
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white, lineWidth: 5))
                        .shadow(radius: 10)

                    Text("Receta tradicional de Caldillo Durangueño")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                        .padding(.bottom, 10)

                    VStack(alignment: .leading, spacing: 25) {
                        // Ingredientes
                        VStack(alignment: .leading) {
                            Text("**Ingredientes (Para 4-6 personas)**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("• 1 kg de carne de res (en cubos)\n\n• 2 chiles guajillos\n\n• 1 chile ancho\n\n• 1 cebolla mediana (finamente picada)\n\n• 2 dientes de ajo (finamente picados)\n\n• 1 zanahoria (en rodajas)\n\n• 1 papa (en cubos)\n\n• 1/2 taza de caldo de res\n\n• 1 cucharadita de comino\n\n• 1/2 cucharadita de orégano\n\n• 1 cucharadita de sal\n\n• 1 cucharadita de pimienta\n\n• Aceite para freír")
                                .font(.body)
                                .foregroundColor(.gray)
                                .padding(.top, 5)
                        }

                        // Instrucciones
                        VStack(alignment: .leading) {
                            Text("**Instrucciones**:")
                                .font(.title3)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)

                            Text("1. En un sartén grande, calienta un poco de aceite y fríe la carne de res hasta que esté dorada por todos lados.\n\n2. En un sartén aparte, tuesta los chiles guajillos y anchos. Luego, lícualos con un poco de agua para hacer una salsa.\n\n3. En la misma sartén donde doraste la carne, añade la cebolla y el ajo, y fríe hasta que estén dorados.\n\n4. Agrega la salsa de chile, el caldo de res, el comino, el orégano, la sal y la pimienta. Cocina a fuego lento durante 10 minutos.\n\n5. Incorpora las zanahorias, las papas y la carne de res. Cocina todo junto por unos 30 minutos o hasta que las verduras estén tiernas.\n\n6. ¡Disfruta de tu Caldillo Durangueño!")
                                .font(.body)
                                .foregroundColor(.black)
                                .padding(.top, 5)
                        }
                    }
                    .padding([.horizontal, .bottom], 20)
                    .background(RoundedRectangle(cornerRadius: 20).fill(Color.white.opacity(0.7)).shadow(radius: 10))
                }
                .padding(.horizontal, 20)
                .background(
                    Image("Otomi")
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .clipped()
                        .edgesIgnoringSafeArea(.all)
                )
            }
            .navigationTitle("Recetachis")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    RecetaDuran()
}
