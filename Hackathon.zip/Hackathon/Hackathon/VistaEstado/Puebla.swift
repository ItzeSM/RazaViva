//
//  Puebla.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct Puebla: View {
        var body: some View {
            NavigationStack {
                VStack(alignment: .leading, spacing: -115) {
                        
                        PostitWithImage(text: "Tradiciones: La Batalla del 5 de Mayo se conmemora con desfiles y eventos históricos.", imageName: "")
                        
                       
                    HStack(alignment: .center, spacing: 5) {
                        PostitWithImage(text: "Comida: Chiles en nogada, chiles rellenos con carne, frutas y cubiertos con crema de nuez.\nBebida: Sidra poblana, una bebida espumosa de manzana tradicional en Navidad.", imageName: "")
                            
                        
                        
                        if let _ = UIImage(named: "TamalChis") {
                            NavigationLink(destination: RecetachisView()) {
                                Image("TamalChis")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 80, height: 80)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.black, lineWidth: 2))
                                    .shadow(radius: 5)
                            }.padding(.leading, -400)
                            .buttonStyle(PlainButtonStyle())
                            
                            
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                        
                        
                        PostitWithImage(text: "Lenguas/Dialectos: Español, totonaco y náhuatl en varias comunidades.", imageName: "")
                    }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                           .padding(.top, 20)
                           .navigationTitle("Chiapas")
            }
        }
    }
    #Preview{
        Puebla()
    }

