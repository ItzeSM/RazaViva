//
//  OaxacaView.swift
//  Hackathon
//
//  Created by Itzel Santiago on 27/03/25.
//
import SwiftUI

struct OaxacaView: View {
    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 1.0, green: 0.759, blue: 0.496)
                    .ignoresSafeArea()
                
                VStack(alignment: .leading, spacing: -115) {
                    
                    Image("oaxaqueña")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 250)
                        .cornerRadius(12)
                        .shadow(radius: 5)
                        .padding(.bottom, 10)
                        .offset(x: 500, y: -190)
                    
                    PostitWithImage(text: "Tradiciones: La Guelaguetza es una de las festividades más importantes de Oaxaca, celebrada en julio, con danzas, música y comida típica de la región.", imageName: "")
                    
                }
                HStack(alignment: .center, spacing: 5) {
                    PostitWithImage(text: "Comida: Las tlayudas son un platillo tradicional de Oaxaca, hechas con una gran tortilla de maíz, frijoles, queso, carne y salsa, a veces acompañadas de tasajo o cecina.\n Bebida: Mezcal, detilado de agave que se produce en varias regiones del estado, de forma artesanal ", imageName: "")
                    
                   
             if let _ = UIImage(named: "TamalChis") {
                        VStack(spacing: 10) {
                        NavigationLink(destination: RecetachisView()) {
                            Image("TamalChis")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.black, lineWidth: 2))
                            .shadow(radius: 5)
                    }
                        .buttonStyle(PlainButtonStyle())
                                              
                        NavigationLink(destination: RecetaBebiChis()) {
                            Image("Mezcal")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(Color.black, lineWidth: 2))
                            .shadow(radius: 5)
                }
                        .buttonStyle(PlainButtonStyle())
            }
                        .padding(.leading, -400)
        }
    }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    PostitWithImage(text: "Lenguas/Dialectos: En Oaxaca se hablan muchas lenguas indígenas, como el zapoteco, mixteco, mazateco y chatino.", imageName: "")
                }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                       .padding(.top, 20)
                       .navigationTitle("Oaxaca")
        }
    }
}

#Preview {
    OaxacaView()
}


