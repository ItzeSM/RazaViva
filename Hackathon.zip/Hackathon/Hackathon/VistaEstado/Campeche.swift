//
//  Campeche.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct Campeche: View {
        var body: some View {
            NavigationStack {
                VStack(alignment: .leading, spacing: -115) {
                        
                        PostitWithImage(text: "Tradiciones: La Feria de Chiapas es un evento cultural donde se calelebran danzas, ritos y exposiciones artísticas. También es importante la Fiesta de la Virgen de la Candelaria, que combina tradiciones religiosas y culturales con danzas.", imageName: "")
                        
                       
                    HStack(alignment: .center, spacing: 5) {
                        PostitWithImage(text: "Comida: Pan de cazón, un plato de tortillas con cazón (tiburón pequeño) en salsa de tomate.\nBebida: La Charanda es un aguardiente que surge por destilación del jugo de caña o de sus derivados, como son el el piloncillo, la melaza o la propia azúcar cristalizada.", imageName: "")
                            
                        
                        
                        if let _ = UIImage(named: "PanDeCazon") {
                            NavigationLink(destination: RecetachisView()) {
                                Image("PanDeCazon")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 80, height: 80)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.black, lineWidth: 2))
                                    .shadow(radius: 5)
                            }.padding(.leading, -400)
                            .buttonStyle(PlainButtonStyle())
                            
                            
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                        
                        
                        PostitWithImage(text: "Lenguas/Dialectos: Español.", imageName: "")
                    }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                           .padding(.top, 20)
                           .navigationTitle("Campeche")
            }
        }
    }
    #Preview{
        Campeche()
    }

