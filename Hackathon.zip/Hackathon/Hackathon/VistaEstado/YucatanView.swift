//
//  YucatanView.swift
//  Hackathon
//
//  Created by Itzel Santiago on 27/03/25.
//

import SwiftUI

struct YucatanView: View {
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: -115) {
                    
                    PostitWithImage(text: "Tradiciones: La celebración de la Fiesta de la Candelaria, donde se realizan danzas y se presenta la gastronomía local.", imageName: "")
                    
                   
                HStack(alignment: .center, spacing: 5) {
                    PostitWithImage(text: "Comida:La cochinita pibil, cerdo marinado en achiote y jugo de naranja agria, cocido lentamente en un horno de tierra.\n Bebida: se produce a partir de miel de abejas alimentadas con la flor del Xtabentún", imageName: "")
                        
                    
                    if let _ = UIImage(named: "TamalChis") {
                        VStack(spacing: 10) {
                            NavigationLink(destination: RecetachisView()) {
                                Image("CochiYuc")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.black, lineWidth: 2))
                                    .shadow(radius: 5)
                            }
                            .buttonStyle(PlainButtonStyle())
                            
                            NavigationLink(destination: RecetaBebiChis()) {
                                Image("Xtabentún")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                                    .padding(.top,15)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.black, lineWidth: 2))
                                    .shadow(radius: 5)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                        .padding(.leading, -400)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                    
                    
                    PostitWithImage(text: "Lenguas/Dialectos: En Chiapas se hablan muchas lenguas indígenas, entre ellas tzeltal, tzotzil, ch’ol y mame.", imageName: "")
                }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                       .padding(.top, 20)
                       .navigationTitle("Chiapas")
        }
    }
}

#Preview{
    YucatanView()
}

