//
//  Sonora.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct Sonora: View {
        var body: some View {
            NavigationStack {
                VStack(alignment: .leading, spacing: -115) {
                        
                        PostitWithImage(text: "Tradiciones: Danza del venado es una danza donde los bailarines recrean una dramática casa de venados en honor al mundo natural y al venado de cola blanca.", imageName: "")
                        
                       
                    HStack(alignment: .center, spacing: 5) {
                        PostitWithImage(text: "Comida: Carne asada, un platillo emblemático que se acompaña con guacamole, cebollitas asadas, salsa, y limones.\n Bebida: Tepache, bebida hecha a base de cascara de piña fermentada. ", imageName: "")
                            
                        
                        
                        if let _ = UIImage(named: "TamalChis") {
                            NavigationLink(destination: RecetaSono()) {
                                Image("TamalChis")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 80, height: 80)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.black, lineWidth: 2))
                                    .shadow(radius: 5)
                            }.padding(.leading, -400)
                            .buttonStyle(PlainButtonStyle())
                            
                            
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                        
                        
                        PostitWithImage(text: "Lenguas/Dialectos: Español y Mayo, Lengua de la familia yuto-nahua, hablada en el sur de Sonora y norte de Sinaloa.", imageName: "")
                    }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                           .padding(.top, 20)
                           .navigationTitle("Chiapas")
            }
        }
    }
    #Preview{
        Sonora()
    }

