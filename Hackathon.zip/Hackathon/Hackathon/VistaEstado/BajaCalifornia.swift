//
//  BajaCalifornia.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct BajaCalifornia: View {
        var body: some View {
            NavigationStack {
                VStack(alignment: .leading, spacing: -115) {
                        
                        PostitWithImage(text: "Tradiciones: La Fiesta de la Vendimia en Ensenada celebra la cosecha del vino con degustaciones y festivales.", imageName: "")
                        
                       
                    HStack(alignment: .center, spacing: 5) {
                        PostitWithImage(text: "Comida: Tacos de pescado, característicos de la costa, con pescado capeado, col rallada y crema. ", imageName: "")
                            
                        
                        
                        if let _ = UIImage(named: "TamalChis") {
                            NavigationLink(destination: RecetachisView()) {
                                Image("TamalChis")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 80, height: 80)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.black, lineWidth: 2))
                                    .shadow(radius: 5)
                            }.padding(.leading, -400)
                            .buttonStyle(PlainButtonStyle())
                            
                            
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                        
                        
                        PostitWithImage(text: "Lenguas/Dialectos: Predomina el Español, con pequeñas comunidades indígenas que hablan kiliwa y pai pai.", imageName: "")
                    }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                           .padding(.top, 20)
                           .navigationTitle("Chiapas")
            }
        }
    }
    #Preview{
        BajaCalifornia()
    }

