//
//  Guanajuato.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct Guanajuato: View {
        var body: some View {
            NavigationStack {
                VStack(alignment: .leading, spacing: -115) {
                        
                        PostitWithImage(text: "Tradiciones:El Festival Cervantino es un evento internacional de arte y cultura.", imageName: "")
                        
                       
                    HStack(alignment: .center, spacing: 5) {
                        PostitWithImage(text: "Comida:Enchiladas mineras, tortillas rellenas de queso y bañadas en salsa de chile guajillo.\nBebida: Agua de betabel, una bebida refrescante y nutritiva.", imageName: "")
                            
                        
                        
                        if let _ = UIImage(named: "TamalChis") {
                            NavigationLink(destination: RecetachisView()) {
                                Image("TamalChis")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 80, height: 80)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.black, lineWidth: 2))
                                    .shadow(radius: 5)
                            }.padding(.leading, -400)
                            .buttonStyle(PlainButtonStyle())
                            
                            
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                        
                        
                        PostitWithImage(text: "Lenguas/Dialectos: Español y algunos hablantes de otomí en algunas comunidades originarias.", imageName: "")
                    }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                           .padding(.top, 20)
                           .navigationTitle("Chiapas")
            }
        }
    }
    #Preview{
        Guanajuato()
    }

