//
//  BajaCaliforniaSur.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct BajaCaliforniaSur: View {
        var body: some View {
            NavigationStack {
                VStack(alignment: .leading, spacing: -115) {
                        
                        PostitWithImage(text: "Tradiciones: Las Fiestas de Fundación de La Paz conmemoran la historia con bailes y desfiles.", imageName: "")
                        
                       
                    HStack(alignment: .center, spacing: 5) {
                        PostitWithImage(text: "Comida: Almejas chocolatas, marisco cocido bajo tierra con hierbas y especias.\nBebida: Licor de damiana, un destilado de una planta local usado en ceremonias antiguas.", imageName: "")
                            
                        
                        
                        if let _ = UIImage(named: "Almeja") {
                            NavigationLink(destination: RecetachisView()) {
                                Image("Almeja")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 80, height: 80)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.black, lineWidth: 2))
                                    .shadow(radius: 5)
                            }.padding(.leading, -400)
                            .buttonStyle(PlainButtonStyle())
                            
                            
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                        
                        
                        PostitWithImage(text: "Español, con hablantes de cochimí en comunidades históricas.", imageName: "")
                    }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                           .padding(.top, 20)
                           .navigationTitle("Baja California Sur")
            }
        }
    }
    #Preview{
        BajaCaliforniaSur()
    }

