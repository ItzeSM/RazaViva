import SwiftUI

struct Chiapas: View {
    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 1.0, green: 0.768, blue: 0.8196)
                    .ignoresSafeArea()
                
                VStack(alignment: .leading, spacing: -115) {
                    
                    Image("chiapaneca")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 250)
                        .cornerRadius(12)
                        .shadow(radius: 5)
                        .padding(.bottom, 10)
                        .offset(x: 500, y: -190)

                    PostitWithImage(text: "Tradiciones: La Feria de Chiapas es un evento cultural donde se celebran danzas, ritos y exposiciones artísticas.", imageName: "")

                 
                }


                VStack(alignment: .leading, spacing: -115) {

                    PostitWithImage(text: "Tradiciones: La Feria de Chiapas es un evento cultural donde se celebran danzas, ritos y exposiciones artísticas.", imageName: "")

                    HStack(alignment: .center, spacing: 5) {
                        PostitWithImage(text: "Comida: El sazón que va del pasado al presente y al futuro: Los tamales con sus diferentes guisos siguen siendo parte fundamental de la gastronomía chiapaneca", imageName: "")

                        if let _ = UIImage(named: "TamalChis") {
                            VStack(spacing: 10) {
                                NavigationLink(destination: RecetachisView()) {
                                    Image("TamalChis")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 100, height: 100)
                                        .clipShape(Circle())
                                        .overlay(Circle().stroke(Color.black, lineWidth: 2))
                                        .shadow(radius: 5)
                                }
                                .buttonStyle(PlainButtonStyle())

                                NavigationLink(destination: RecetaBebiChis()) {
                                    Image("Pozol")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 100, height: 100)
                                        .clipShape(Circle())
                                        .overlay(Circle().stroke(Color.black, lineWidth: 2))
                                        .shadow(radius: 5)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                            .padding(.leading, -400)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    PostitWithImage(text: "Lenguas/Dialectos: En Chiapas se hablan muchas lenguas indígenas, entre ellas tzeltal, tzotzil, ch’ol y mame.", imageName: "")
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                .padding(.top, 20)
            }
            .navigationTitle("Chiapas")
        }
    }
}

#Preview {
    Chiapas()
}
