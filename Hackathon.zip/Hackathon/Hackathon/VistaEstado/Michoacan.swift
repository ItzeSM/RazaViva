//
//  Michoacan.swift
//  Hackathon
//
//  Created by Itzel Santiago on 31/03/25.
//

import SwiftUI

struct Michoacan: View {
        var body: some View {
            NavigationStack {
                VStack(alignment: .leading, spacing: -115) {
                        
                        PostitWithImage(text: "Tradiciones:La Noche de Muertos en Pátzcuaro es una de las celebraciones más emblemáticas del Día de Muertos.", imageName: "")
                        
                       
                    HStack(alignment: .center, spacing: 5) {
                        PostitWithImage(text: "Comida: Corundas, tamales triangulares de maíz con crema y queso.\nBebida: Charanda, un aguardiente de caña similar al ron.", imageName: "")
                            
                        
                        
                        if let _ = UIImage(named: "TamalChis") {
                            NavigationLink(destination: RecetachisView()) {
                                Image("TamalChis")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 80, height: 80)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.black, lineWidth: 2))
                                    .shadow(radius: 5)
                            }.padding(.leading, -400)
                            .buttonStyle(PlainButtonStyle())
                            
                            
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                        
                        
                        PostitWithImage(text: "Lenguas/Dialectos: Español y purépecha en comunidades originarias.", imageName: "")
                    }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                           .padding(.top, 20)
                           .navigationTitle("Chiapas")
            }
        }
    }
    #Preview{
        Michoacan()
    }

